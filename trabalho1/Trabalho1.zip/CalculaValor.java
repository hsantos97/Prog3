public interface CalculaValor {
	public void calculaValorDiaria();
}
